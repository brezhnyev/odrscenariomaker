usage:
./PlyViewer.sh /home/kbrezhnyev/DATA/temp/output_folder/ 30

first argument: single file with .ply extension OR folder containing ply file(s)
second argument: desired FPS of playback

git repo:
https://git.altran.de/imageproc/plyviewer.git
